function love.conf(t)
        t.title = "fuck lol"
        t.version = "0.10.1"
        t.window.width = 600
        t.window.height = 600
        t.console = true
end

